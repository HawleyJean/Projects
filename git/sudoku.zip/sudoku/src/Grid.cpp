#include <iostream>
#include "Grid.h"

using namespace std;

void Grid::display()
{
	for (int i = 0; i < 9; i++)
	{
		if ((i+1)%3 == 0)
		{
			cout << num_array[i] << "\n";
		}
		else
		{
			cout << num_array[i] << " ";
		}
	}
}

