#ifndef GRID_H
#define GRID_H
#include "Collec.h"
#include <iostream>


using namespace std;

class Grid: public Collec
{
	public: 
		Grid() {};
		~Grid() {};
			
			virtual void display() override;
};

#endif