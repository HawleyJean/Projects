#include<fstream>  
#include<fstream>  
#include<iostream>  
#include<string>  
#include<stdio.h>  
#include "Row.h"
#include "Column.h"
#include "Grid.h"

using std::ifstream;

using namespace std; 
extern int flag;

class Gameboard
{
protected:
	int a[9][9];
	bool gameWon;
	bool permissions[9][9];

	//row collumn
public:
	Gameboard() { gameWon = false; };

	void insert(int row, int column, int val);

	void readfile(string s);	
	
	void selectLevel(int a);

	void display_array();

	bool getUserInput();
	
	void checkIfWon();

	bool getBool(){
		return gameWon;
	}
	
	void setBool(bool bb) {
		gameWon = bb;
	}

	Row makeRow(int row);
	
	Column makeColumn(int col);
	
	Grid makeGrid(int x, int y);
};



