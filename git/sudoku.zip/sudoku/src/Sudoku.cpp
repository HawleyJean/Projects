// Sudoku.cpp : Defines the entry point for the console application.
//

#include "Gameboard.h"

#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>

using namespace std;



int main()
{
	

	bool ongoing= true;
	bool playagain = true;

	int level = 0;

	string exit = "";
	cout << "Welcome to our Sudoku Game! \nAnytime you wish to leave, please press e\n";
	
	Gameboard game;

	while (playagain) {
		cout << "Choose your level! 1 - 3\n";
		ongoing = true;
		cin >> level;

		if (level > 4 || level < 1) 
		{
			cout << "Invalid level, try again\n";
			ongoing = false;
		}
		else 
		{
			ongoing = true;
			game.selectLevel(level);
		}
		while (ongoing)
		{
			game.display_array();

			cout << "\n\nEnter your row, column, and number\n";

			game.getUserInput();
			game.checkIfWon();
			if (game.getBool())
			{
				game.display_array();

				cout << "You just won the game! Would you like to play again? y or n \n ";
				cin >> exit;
				ongoing = false;		
			}

		}
		if (game.getBool()) {
			if (exit == "y")
			{
				playagain = true;
				ongoing = true;
				game.setBool(false);
			}
			else
			{
				playagain = false;
				cout << "Thanks for playing sudoku!\n";
			}
		}

	}

	getchar();

	getchar();
    return 0;


	}

