#ifndef ROW_H
#define ROW_H
#include <iostream>
#include "Collec.h"

using namespace std;

class Row: public Collec
{
	public:
		Row() {};
		~Row() {};
			
			virtual void display() override;
};

#endif // !ROW_H