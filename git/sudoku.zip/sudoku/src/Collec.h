#pragma once
#include <iostream>

using namespace std;

class Collec
{
protected:
	int num_array[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	bool isDistinct = false;

public:
	Collec() {};
	
	~Collec() {};
	
	Collec(int arr[9]) {
		initNum_array(arr);
	};

	int * getArray() 
	{
		int * arr;
		arr = num_array;
		return arr;
	};

	bool checkDistinct();


	virtual void display() = 0;

	void initNum_array(int arr[9]);
};