#ifndef COLUMN_H
#define COLUMN_H
#include <iostream>
#include "Collec.h"


using namespace std;

class Column: public Collec
{
	public:
		Column() {};
		~Column() {};
		
		virtual void display() override;
};

#endif