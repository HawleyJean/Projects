

#include "Gameboard.h"

using namespace std; 
void Gameboard::selectLevel(int a) 
{
	string fnam = "";
	if (a == 4) 
	{
		fnam = "d.txt";
	}
	else if (a == 1) 
	{
		fnam = "a.txt";
	}
	else if (a == 2) 
	{
		fnam = "b.txt";
	}
	else if (a == 3) 
	{
		fnam = "c.txt";
	}
	else {
		cout << "\nInvalid level!\n";
	}
	if (fnam != "") {
		readfile(fnam);
	}

}
void Gameboard::readfile(string s)
{
   
   ifstream in;
   in.open(s);
	//ifstream  file(s);
   

	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			in >> a[i][j];
			if (a[i][j] == 0) 
			{
				permissions[i][j] = true;
			}
			else {
				permissions[i][j] = false;
			}

		}
	}
	cout << "File read! gameboard created!\n";
}

void Gameboard::insert(int row, int column, int val) 
{
	if (permissions[row - 1][column - 1] == false) {
		cout << "You cannot change preset numbers!\n";
	}
	else
	{
		if ((row > 9 || row < 1) || (column < 1 || column>9) || (val > 9 || val < 1))
		{
			cout << "\nCannot change the values! Out of range\n";
		}
		else 
		{
			a[(row - 1)][(column - 1)] = val;
		}
	}
}

void Gameboard::display_array()
{
	//print sudoku1 to screen
	cout << "--------------------------" << endl;
	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			if (j % 3 == 0)
			{
				cout << "| ";
			}
			if (a[i][j] == 0)
				cout << "  ";
			else
			{
				cout << a[i][j] << " ";
			}
		}
		cout << "| ";
		cout << endl;
		if ((i + 1) % 3 == 0)
		{
			cout << "--------------------------" << endl;
		}
	}
	cout << endl;
}

bool Gameboard::getUserInput() 
{
	bool gamequit = true;
	string a, b, c;
	int aa, bb, cc;
	getline(cin, a, ' ');
	if (a == "exit") 
	{
		cout << "closing now!";
		gamequit = false;
	}
	else 
	{
		getline(cin, b, ' ');
		getline(cin, c, '\n');

		aa = stoi(a);
		bb = stoi(b);
		cc = stoi(c);
		insert(aa, bb, cc);
	}
	return gamequit;
}

Row Gameboard::makeRow(int row) 
{
	int arr[9];
	for (int i = 0; i < 9; i++) 
	{
		arr[i] = a[row][i];
	}
	Row roww;
	roww.initNum_array(arr);
	return roww;
}

Column Gameboard::makeColumn(int col) 
{
	int arr[9];
	for (int i = 0; i < 9; i++) 
	{
		arr[i] = a[i][col];
	}
	
	Column coll;

	coll.initNum_array(arr);

	return coll;
}

Grid Gameboard::makeGrid(int x, int y) 
{
	int counter = 0;
	int arr[9];

	for (int i = y; i < (y + 3); i++) 
	{
		for (int j = x; j < (x + 3); j++) 
		{
			arr[counter] = a[i][j];
			counter++;
		}
	}

	Grid gr;
	gr.initNum_array(arr);
	return gr;
}

void Gameboard::checkIfWon() 
{
	bool foundDup= false;

	Row * rPtr= new Row();
	
	Column *cPtr = new Column();

	Grid *gPtr = new Grid();

	while (!foundDup) 
	{
		for (int i = 0; i < 9; i++)
		{
			*rPtr = (makeRow(i));
			foundDup = rPtr->checkDistinct();
			if (foundDup) 
			{
				break;
			}
		}

		if (foundDup)
		{
			break;
		}
		
		for (int k = 0; k < 9; k++) 
		{
			*cPtr = (makeColumn(k));
			foundDup = cPtr->checkDistinct();
			if (foundDup) 
			{
				break;
			}
		}
		
		if (foundDup)
		{
			break;
		}

		int count = 0;
		for (int j = 0; j < 8; j=(j + 3)) 
		{
			
			for (int p = 0; p < 8; p = (p + 3)) 
			{
				*gPtr=makeGrid(p,j);
				foundDup=gPtr->checkDistinct();
				count++;
				if (foundDup)
				{
					break;
				}
			}
			if (foundDup) 
			{
				break;
			}
		}
		if (foundDup) 
		{
			break;
		}
		break;
	}
	if (foundDup) 
	{ 
		cout << "= \nOngoing!\n"; 
	}
	else 
	{ 
		cout << "No duplicates! games over\n";
		gameWon = true;
	}
	delete cPtr;
	delete rPtr;
	delete gPtr;

}