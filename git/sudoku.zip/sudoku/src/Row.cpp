#include <iostream>
#include "Row.h"

using namespace std;

void Row::display()
{
	for (int i = 0; i < 9; i++)
	{
		cout << num_array[i] << " ";
	}
		
		cout << "\n";
};

