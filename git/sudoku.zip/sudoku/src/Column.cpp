#include <iostream>
#include "Column.h"

using namespace std;


void Column::display()
{
	for (int i = 0; i < 9; i++)
	{
		cout << num_array[i] << "\n";
	}
}

