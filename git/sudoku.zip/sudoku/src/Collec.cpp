#include "Collec.h"

void Collec::initNum_array(int arr[9]) 
{
	for (int i = 0; i < 9; i++) 
	{
		num_array[i] = arr[i];
	}
}

bool Collec::checkDistinct() 
{
		bool foundDup = false;

			for (int i = 0; i < 9; i++)
			{
				if (num_array[i] == 0)
				{
					foundDup = true;
				}
				else
				{
					for (int k = 0; k < 9; k++)
					{
						if (k != i)
						{
							if (num_array[k] == num_array[i])
							{
								foundDup = true;
							
							}
						}
					}
				}
			}
		return foundDup;
	}

