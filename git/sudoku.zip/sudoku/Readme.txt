#*****Makefile*****
# Compiler to use.
CC=g++
# Options to pass
CFLAGS =-c -Wall

all: Sudoku

Sudoku: main.o Gameboard.o Collec.o Row.o Column.o Grid.o
	$(CC) main.o Gameboard.o Collec.o Row.o Column.o Grid.o -o Sudoku

main.o: Sudoku.cpp
	$(CC) $(CFLAGS) Sudoku.cpp

Gameboard.o: Gameboard.cpp 
	$(CC) $(CFLAGS) Gameboard.cpp

Collec.o: Collec.cpp
	$(CC) $(CFLAGS) Collec.cpp

Row.o: Row.cpp
	$(CC) $(CFLAGS) Row.cpp

Column.o: Column.cpp 
	$(CC) $(CFLAGS) Column.cpp 

Grid.o: Grid.cpp
	$(CC) $(CFLAGS) Grid.cpp

clean:
	rm *o Sudoku


#*****Run the program****

make -f Makefile
./SudoKu